# Github-like Pandoc Template

Produces a single html page that can be hosted on Github.

Simply push everything to a new repo and, in "Settings/Pages", activate the pages from master and "/ (root)".